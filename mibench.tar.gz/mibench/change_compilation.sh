#!/bin/bash
declare -A binaries

if [ $# -ne 4 ]; then
  echo "Must specific all the parameters!!!!!"
  echo "Usage: ./change_compilation.sh [object] [compilation_method] [idempotent_preservation] [checkpoint] "
  echo "For example: ./change_compilation.sh sha static none cp"
  echo "For example: ./change_compilation.sh sha static vcf none"
  exit 1
fi 

if [ $1 == "all" ]; then
  benchs=("sha" "susan")
else
  benchs=("$1")
fi
COMPILE_METHOD="$2"
IDEM_PRESERVE="$3"
CHECKPOINT="$4"
#grep -rl "preservation=vcf" | xargs sed -i "s/preservation=vcf/preservation=none/g"


MAKEFILE="Makefile.${COMPILE_METHOD}"
echo "Replacing all the Makefile with ${MAKEFILE}"
#apps=("perlbench" "bzip2" "gcc" "mcf" "milc" "namd" "gobmk" "dealII" "soplex" "hmmer" "sjeng" "libquantum" "h264ref" "lbm" "omnetpp" "astar" "Xalan")
binaries=(["bitcount"]="bitcnts" ["pgp"]="pgp" ["qsort"]="qsort_large" ["sha"]="sha" ["susan"]="susan")
benchNum=${#benchs[@]}
HOMEDIR="/home/lqingrui"
MEDIA_DIR_BASE="${HOMEDIR}/Benchmark/mibench"

for i in ${benchs[*]}; do
  #if [ ${i} == "gsm" ]; then
  pushd ${MEDIA_DIR_BASE}/${i}
      rm Makefile
      if [ $? -ne 0 ]; then
        echo "${i} Cannot remove Makefile!"
        exit 1 
      fi
      cp ${MAKEFILE} Makefile
      if [ $? -ne 0 ]; then
        echo "${i} Cannot cp Makefile!"
        exit 1 
      fi
  #fi

  # dirty hack: need to change these options LLVM in the future.
  grep -r "idempotence-preservation=${IDEM_PRESERVE}" * > /dev/null
  if [ $? -ne 0 ]; then
    if [ ${IDEM_PRESERVE} == "vcf" ]; then
      grep -rl "idempotence-preservation=none" * | xargs sed -i "s/idempotence-preservation=none/idempotence-preservation=${IDEM_PRESERVE}/g"
    else
      grep -rl "idempotence-preservation=vcf" * | xargs sed -i "s/idempotence-preservation=vcf/idempotence-preservation=${IDEM_PRESERVE}/g"
    fi
  else
    echo "--idempotence-preservation=${IDEM_PRESERVE} exist, no need to change"
  fi

  grep -r "livein-checkpoint=$CHECKPOINT" * > /dev/null
  if [ $? -ne 0 ]; then
    if [ ${CHECKPOINT} == "cp" ]; then
      grep -rl "livein-checkpoint=none" * | xargs sed -i "s/livein-checkpoint=none/livein-checkpoint=${CHECKPOINT}/g"
    else
      grep -rl "livein-checkpoint=cp" * | xargs sed -i "s/livein-checkpoint=cp/livein-checkpoint=${CHECKPOINT}/g"
    fi
  else
    echo "--livein-checkpoint=${CHECKPOINT} exist, no need to change"
  fi

  popd
done





