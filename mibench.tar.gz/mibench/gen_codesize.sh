#!/bin/bash

declare -A binaries

if [ $1 == "all" ]; then
  #benchs=("bitcount" "pgp" "qsort" "sha" "susan")
  benchs=("sha" "susan")
else
  benchs=("$1")
fi
#apps=("perlbench" "bzip2" "gcc" "mcf" "milc" "namd" "gobmk" "dealII" "soplex" "hmmer" "sjeng" "libquantum" "h264ref" "lbm" "omnetpp" "astar" "Xalan")
binaries=(["bitcount"]="bitcnts" ["pgp"]="pgp" ["qsort"]="qsort_large" ["sha"]="sha" ["susan"]="susan")
benchNum=${#benchs[@]}
HOMEDIR="/home/lqingrui"
MEDIA_DIR_BASE="${HOMEDIR}/Benchmark/mibench"
BUILDDIR="run/build_base_amd64-m32-gcc42-nn.0000"

UPLOADPRE='spawn scp \-P2200 '
UPLOADPOST=' lqingrui@systemg.cs.vt.edu:mediabenchrun\/'
SPECHOME='\/home\/lqingrui\/Benchmark\/cpu2006\/benchspec\/CPU2006'
BENCHBUILDDIR='run\/build_base_amd64-m32-gcc42-nn.0000'

CODESIZE_REPORT="/home/lqingrui/Benchmark/mibench/codesize.txt"

rm codesize.txt
BeginTime=$(date +"%s")

for i in ${benchs[*]}; do
#   getbinaries() $i
#   echo 
  pushd ${MEDIA_DIR_BASE}/${i}
  for TARGET in ${binaries[${i}][*]}; do
#    echo ${TARGET}
    # firstly compile the source code
#    if [ ${i} == "pgp" ]; then
#      pushd src && make clean && make arm-linux
#      popd
#    else
      make clean && make ${TARGET}

      file ${TARGET} | grep "dynamically linked" > /dev/null
      if [ $? -ne 0 ]; then
        echo "NOT DYNAMICALLY LINKED!!!!!!!!!!!!!!!!!!!!!!!"
        exit 1
      fi

      # move any statical data during compilation to our directory
      #mv ~/CPNum.txt /home/lqingrui/cpfreq/mediabench/${TARGET}
      mv ~/AntiNum.txt /home/lqingrui/cpfreq/AntiInfo/${i}
      
      codesize=$(du -b ${TARGET} | xargs echo | cut -d' ' -f1)
      printf "%-15s %-10d\n" ${TARGET} ${codesize} >> ${CODESIZE_REPORT}
      #echo -e "${TARGET} \c" >> ~/Benchmark/mibench/codesize.txt
      #du -b ${TARGET} | xargs echo | cut -d' ' -f1 >> ~/Benchmark/mibench/codesize.txt
#      mv /home/lqingrui/dupInsts ~/Benchmark/mibench/result/${TARGET}
#    fi
    if [ $? -ne 0 ]; then
      echo "${i} cannot make successfully!"
      exit 1 
    fi
  done
  popd
done

EndTime=$(date +"%s")
ElapsedTime=$((${EndTime}-${BeginTime}))
echo "Total Compilation Time: $((${ElapsedTime} / 60)) minutes and $((${ElapsedTime} % 60)) seconds elapsed."

