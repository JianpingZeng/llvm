#ifndef MOREP_H
#define MOREP_H

extern int more_file(char *fileName, boolean eyes_only);
extern int open_more(void);
extern int close_more(void);

#endif /* MOREP_H */
