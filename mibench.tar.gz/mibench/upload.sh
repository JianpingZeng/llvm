#!/usr/bin/expect
set timeout 3

spawn scp -P2200 sha ztong@systemg.cs.vt.edu:mediabenchrun/
expect "password:"
send "1234qwerA \r"
interact

