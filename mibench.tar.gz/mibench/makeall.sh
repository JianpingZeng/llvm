#!/bin/bash
if [ $# -ne 2 ]; then
  echo "expect two argument. For example ./makeall all idem"
  exit 1
fi

declare -A binaries

BINARYTYPE=$2
if [ $1 == "all" ]; then
  #benchs=("bitcount" "pgp" "qsort" "sha" "susan")
  benchs=("sha" "susan")
else
  benchs=("$1")
fi
#apps=("perlbench" "bzip2" "gcc" "mcf" "milc" "namd" "gobmk" "dealII" "soplex" "hmmer" "sjeng" "libquantum" "h264ref" "lbm" "omnetpp" "astar" "Xalan")
binaries=(["bitcount"]="bitcnts" ["pgp"]="pgp" ["qsort"]="qsort_large" ["sha"]="sha" ["susan"]="susan")
benchNum=${#benchs[@]}
HOMEDIR="/home/lqingrui"
MEDIA_DIR_BASE="${HOMEDIR}/Benchmark/mibench"
BUILDDIR="run/build_base_amd64-m32-gcc42-nn.0000"

UPLOADPRE='spawn scp \-P2200 '
UPLOADPOST=' ztong@systemg.cs.vt.edu:mediabenchrun\/'
#UPLOADPOST=' lqingrui@systemg.cs.vt.edu:mediabenchrun\/'
SPECHOME='\/home\/lqingrui\/Benchmark\/cpu2006\/benchspec\/CPU2006'
BENCHBUILDDIR='run\/build_base_amd64-m32-gcc42-nn.0000'
COPYDIR='/home/lqingrui/binaries/mediabench/'

ORACLEDIR="/home/lqingrui/data/2color/profile"
ORACLE="/home/lqingrui/oracle.txt"

STATIC_REGION_INFO="/home/lqingrui/RegionNum.txt"
STATIC_REGION_INFO_DIR="/home/lqingrui/staticInfo/regionInfo"


pushd ${COPYDIR} &> /dev/null
#mkdir ${COPYDIR}/${BINARYTYPE}
if [ ! -d "${BINARYTYPE}" ]; then
  echo "${COPYDIR}/${BINARYTYPE} doesn't exist!!"
  exit 1
fi
popd &> /dev/null

for i in ${benchs[*]}; do
  rm ${ORACLE}
  cp ${ORACLEDIR}/${i} ${ORACLE}
  if [ $? -ne 0 ]; then
    echo "${i} copy the oracle.txt!"
    exit 1
  fi

  pushd ${MEDIA_DIR_BASE}/${i}
  # firstly compile the source code
  if [ ${i} == "pgp" ]; then
    pushd src && make clean && make arm-linux -j8
  else
    make clean && make -j8
  fi
  if [ $? -ne 0 ]; then
    echo "${i} cannot make successfully!"
    exit 1 
  fi

  #mv ~/CPNum.txt /home/lqingrui/cpfreq/mediabench/${i}
#  if [ ! -d "${STATIC_REGION_INFO_DIR}/${BINARYTYPE}" ]; then
#    mkdir ${STATIC_REGION_INFO_DIR}/${BINARYTYPE}
#  fi
#  mv ${STATIC_REGION_INFO} ${STATIC_REGION_INFO_DIR}/${BINARYTYPE}/${i}

  #secondly, upload it to systemg
  if [ ${i} == "pgp" ]; then
    for binary in ${binaries[${i}]}; do
      cp ${binary} ${COPYDIR}/${BINARYTYPE}
    done
#    sed -i "4s/.*/${UPLOADPRE}${binaries[${i}]}${UPLOADPOST}/" ${MEDIA_DIR_BASE}/upload.sh &&
#    ${MEDIA_DIR_BASE}/upload.sh
#    if [ $? -ne 0 ]; then
#      echo "${i} cannot upload successfully!"
#      exit 1 
#    fi
    popd
  else
    for binary in ${binaries[${i}]}; do
      cp ${binary} ${COPYDIR}/${BINARYTYPE}
    done
#    sed -i "4s/.*/${UPLOADPRE}${binaries[${i}]}${UPLOADPOST}/" ${MEDIA_DIR_BASE}/upload.sh &&
#    ${MEDIA_DIR_BASE}/upload.sh
#    if [ $? -ne 0 ]; then
#      echo "${i} cannot upload successfully!"
#      exit 1 
#    fi
  fi
  popd
done



#cd $LLVMOBJ && make -j4 && make install -j4 &&
#for i in $(seq 0 16);
#do
##   echo ${SPEC2006}\/${benchs[${i}]}\/${BUILDDIR}
#  cd ${SPEC2006}/${benchs[${i}]}/${BUILDDIR} && make clean && make -j4
#  if [ $? -ne 0 ]; then
#    echo "${benchs[${i}]} cannot make successfully!"
#    exit 1 
#  fi
#  sed -i "4s/.*/${UPLOADPRE}${UPLOADPOST}/" ${SPEC2006}/upload.sh &&
#  sed -i "4s/.*/${UPLOADPRE}${SPECHOME}\/${benchs[${i}]}\/${BENCHBUILDDIR}\/${apps[${i}]}${UPLOADPOST}/" ${SPEC2006}/upload.sh &&
#  sleep 1 &&
#  ${SPEC2006}/upload.sh
#done

#cd /home/lqingrui/CPU2006/400.perlbench/build/build_base_x86_64_gcc.0000 && make clean && make -j4 && ../upload.sh && \
#cd /home/lqingrui/CPU2006/401.bzip2/build/build_base_x86_64_gcc.0000 && make clean && make -j4 && ../upload.sh && \
#cd /home/lqingrui/CPU2006/403.gcc/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/429.mcf/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/445.gobmk/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/456.hmmer/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#
## compile 458.sjeng
#cd /home/lqingrui/CPU2006/458.sjeng/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#
## compile 462.libquantum
#cd /home/lqingrui/CPU2006/462.libquantum/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/464.h264ref/build/build_base_x86_64_gcc.0000 && make clean && make -j4 && ../upload.sh && \
#cd /home/lqingrui/CPU2006/471.omnetpp/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/473.astar/build/build_base_x86_64_gcc.0000 && make clean && make -j4&& ../upload.sh && \
#cd /home/lqingrui/CPU2006/483.xalancbmk/build/baseline && make clean && make -j4&& ../upload.sh  



