#!/bin/sh
bitcnts 1125000 > output_large.txt
