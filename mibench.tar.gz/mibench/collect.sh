#!/bin/bash

declare -A binaries

if [ $1 == "all" ]; then
  #benchs=("bitcount" "pgp" "qsort" "sha" "susan")
  benchs=("sha" "susan")
else
  benchs=("$1")
fi
#apps=("perlbench" "bzip2" "gcc" "mcf" "milc" "namd" "gobmk" "dealII" "soplex" "hmmer" "sjeng" "libquantum" "h264ref" "lbm" "omnetpp" "astar" "Xalan")
binaries=(["bitcount"]="bitcnts" ["pgp"]="pgp" ["qsort"]="qsort_large" ["sha"]="sha" ["susan"]="susan")
benchNum=${#benchs[@]}
HOMEDIR="/home/lqingrui"
MEDIA_DIR_BASE="${HOMEDIR}/Benchmark/mibench"
BUILDDIR="run/build_base_amd64-m32-gcc42-nn.0000"

UPLOADPRE='spawn scp \-P2200 '
UPLOADPOST=' lqingrui@systemg.cs.vt.edu:mediabenchrun\/'
SPECHOME='\/home\/lqingrui\/Benchmark\/cpu2006\/benchspec\/CPU2006'
BENCHBUILDDIR='run\/build_base_amd64-m32-gcc42-nn.0000'

for i in ${benchs[*]}; do
#   getbinaries() $i
#   echo 
  pushd ${MEDIA_DIR_BASE}/${i}
  for TARGET in ${binaries[${i}][*]}; do
#    echo ${TARGET}
    # firstly compile the source code
#    if [ ${i} == "pgp" ]; then
#      pushd src && make clean && make arm-linux
#      popd
#    else
      make clean && make ${TARGET}
      echo -e "${TARGET} \c" >> ~/Benchmark/mibench/codesize.txt
      du -b ${TARGET} | xargs echo | cut -d' ' -f1 >> ~/Benchmark/mibench/codesize.txt
#      mv /home/lqingrui/dupInsts ~/Benchmark/mibench/result/${TARGET}
#    fi
    if [ $? -ne 0 ]; then
      echo "${i} cannot make successfully!"
      exit 1 
    fi
  done
  popd
done


